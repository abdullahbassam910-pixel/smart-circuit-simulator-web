﻿import numpy as np

from core.simulation_state import CapacitorState, SolverOptions


class CircuitSolver:
    """
    SMART CIRCUIT SIMULATOR PRO v6.3 ULTRA

    Real solver:
    - Ground-aware MNA / KCL core
    - Ideal voltage source stamping
    - Resistor network solving
    - Diode ON/OFF iteration
    - Capacitor transient stepping using Backward Euler
    - Debug matrix/vector/solution caching
    """

    def __init__(self):
        self.components = []
        self.wires = []

        self.node_manager = None
        self.circuit_manager = None

        self.results = {"success": False, "message": "No analysis run."}

        self.last_matrix_A = None
        self.last_vector_Z = None
        self.last_solution_X = None
        self.last_num_nodes = 0
        self.last_num_voltage_sources = 0
        self.last_elements_count = 0
        self.last_analysis_mode = "dc"
        self.last_error = ""
        self.last_diagnostics = {}

        self.options = SolverOptions()
        self.capacitor_states = {}
        self.current_time = 0.0

    # ==========================================================
    # ATTACHMENTS / OPTIONS
    # ==========================================================
    def set_node_manager(self, manager):
        self.node_manager = manager

    def set_circuit_manager(self, circuit_manager):
        self.circuit_manager = circuit_manager

    def set_options(self, **kwargs):
        for key, value in kwargs.items():
            if hasattr(self.options, key):
                setattr(self.options, key, value)

    def reset_states(self):
        self.capacitor_states = {}

    # ==========================================================
    # MAIN API
    # ==========================================================
    def solve(self, components=None, wires=None, analysis_mode=None, time_step=None, transient_steps=None):
        if components is None or wires is None:
            if self.circuit_manager is None:
                return self._fail("No circuit data provided.")

            prepared = self.circuit_manager.prepare_for_solver()
            components = prepared.get("components", [])
            wires = prepared.get("wires", [])

        self.components = [c for c in (components or []) if not getattr(c, "deleted", False)]
        self.wires = [w for w in (wires or []) if not getattr(w, "deleted", False)]

        if self.node_manager is None:
            return self._fail("Node Manager missing.")

        if not self.components:
            return self._fail("No components found in circuit.")

        try:
            self.node_manager.sync_circuit(self.components, self.wires)
        except Exception as exc:
            return self._fail(f"Node sync failed: {exc}")

        if not self.node_manager.has_ground():
            return self._fail("Ground component required for simulation.")

        self.last_num_nodes = self.node_manager.get_total_nodes()
        self.last_elements_count = len(self.components)

        if self.last_num_nodes < 2:
            return self._fail("Circuit is incomplete. Need at least one grounded network.")

        mode = self._resolve_analysis_mode(analysis_mode)
        if mode not in {"dc", "transient"}:
            return self._fail("Analysis mode must be dc, transient, or auto.")

        self.last_analysis_mode = mode

        step = float(time_step if time_step is not None else self.options.time_step)
        total_steps = int(transient_steps if transient_steps is not None else self.options.transient_steps)

        if step <= 0:
            return self._fail("Time step must be greater than zero.")

        if total_steps <= 0:
            return self._fail("Transient steps must be greater than zero.")

        if mode == "transient":
            return self._solve_transient(step, total_steps)

        return self._solve_dc()

    def solve_circuit(self, prepared_data, **solve_kwargs):
        if not isinstance(prepared_data, dict):
            return self._fail("Invalid prepared solver data.")

        return self.solve(
            prepared_data.get("components", []),
            prepared_data.get("wires", []),
            **solve_kwargs,
        )

    # ==========================================================
    # ANALYSIS MODES
    # ==========================================================
    def _resolve_analysis_mode(self, analysis_mode):
        if analysis_mode is not None:
            mode = str(analysis_mode).strip().lower()
            if mode != "auto":
                return mode

        for comp in self.components:
            if self._get_component_type(comp) == "capacitor":
                return "transient"

        return str(self.options.analysis_mode).strip().lower()

    def _solve_dc(self):
        iteration = self._iterate_nonlinear_solution(mode="dc", time_step=None)
        if not iteration["success"]:
            return iteration

        return self._build_result(
            iteration["solution"],
            iteration["plan"],
            mode="dc",
            time_step=None,
            transient_snapshots=[],
        )

    def _solve_transient(self, time_step, transient_steps):
        transient_snapshots = []
        latest = None

        for step_index in range(max(1, transient_steps)):
            self.current_time = (step_index + 1) * time_step
            iteration = self._iterate_nonlinear_solution(mode="transient", time_step=time_step)
            if not iteration["success"]:
                return iteration

            latest = iteration

            step_result = self._build_result(
                iteration["solution"],
                iteration["plan"],
                mode="transient",
                time_step=time_step,
                transient_snapshots=[],
            )

            transient_snapshots.append({
                "step": step_index + 1,
                "time": round((step_index + 1) * time_step, 9),
                "node_voltages": list(step_result.get("node_voltages", [])),
                "component_results": list(step_result.get("component_results", [])),
            })

            self._commit_capacitor_state(step_result)

        if latest is None:
            return self._fail("Transient solver produced no steps.")

        final_result = self._build_result(
            latest["solution"],
            latest["plan"],
            mode="transient",
            time_step=time_step,
            transient_snapshots=transient_snapshots,
        )
        final_result["message"] = f"Transient analysis successful ({len(transient_snapshots)} steps)."
        self.results = final_result
        return final_result

    # ==========================================================
    # NONLINEAR ITERATION
    # ==========================================================
    def _iterate_nonlinear_solution(self, mode, time_step):
        diode_modes = {}
        solution = None
        plan = None

        for _ in range(self.options.diode_max_iterations):
            plan = self._build_element_plan(diode_modes, mode, time_step)
            matrix_data = self.build_matrix(plan)
            if not matrix_data["success"]:
                return matrix_data

            solution = self._solve_linear_system(matrix_data["A"], matrix_data["Z"], allow_regularization=True)
            if not solution["success"]:
                return solution

            updated_modes = self._evaluate_diode_modes(solution["X"])

            if updated_modes == diode_modes:
                final_plan = self._build_element_plan(updated_modes, mode, time_step)
                final_check = self._check_floating_nodes(final_plan)
                if not final_check["success"]:
                    return self._fail(final_check["message"], diagnostics=final_check)

                final_matrix = self.build_matrix(final_plan)
                if not final_matrix["success"]:
                    return final_matrix

                final_solution = self._solve_linear_system(final_matrix["A"], final_matrix["Z"])
                if not final_solution["success"]:
                    return final_solution

                return {
                    "success": True,
                    "solution": final_solution["X"],
                    "plan": final_plan,
                }

            diode_modes = updated_modes

        if solution is None or plan is None:
            return self._fail("Solver could not build a valid analysis plan.")

        final_plan = self._build_element_plan(diode_modes, mode, time_step)
        final_check = self._check_floating_nodes(final_plan)
        if not final_check["success"]:
            return self._fail(final_check["message"], diagnostics=final_check)

        final_matrix = self.build_matrix(final_plan)
        if not final_matrix["success"]:
            return final_matrix

        final_solution = self._solve_linear_system(final_matrix["A"], final_matrix["Z"])
        if not final_solution["success"]:
            return final_solution

        return {
            "success": True,
            "solution": final_solution["X"],
            "plan": final_plan,
        }

    # ==========================================================
    # ELEMENT PLAN
    # ==========================================================
    def _build_element_plan(self, diode_modes, mode, time_step):
        elements = []
        source_components = []

        for comp in self.components:
            comp_type = self._get_component_type(comp)
            comp_id = getattr(comp, "id", None)
            value = self._safe_float(getattr(comp, "value", 0.0), default=0.0)
            n1 = self.node_manager.get_node_index(comp_id, 1)
            n2 = self.node_manager.get_node_index(comp_id, 2)

            if n1 < 0 or n2 < 0:
                continue

            if comp_type == "ground":
                elements.append({
                    "component": comp,
                    "kind": "ground",
                    "n1": n1,
                    "n2": n2,
                    "value": 0.0,
                    "model": "reference_node",
                })
                continue

            if comp_type == "resistor":
                resistance = max(abs(value), 1e-9)
                elements.append({
                    "component": comp,
                    "kind": "resistor",
                    "n1": n1,
                    "n2": n2,
                    "value": resistance,
                    "conductance": 1.0 / resistance,
                    "model": "ohmic",
                })
                continue

            if comp_type == "battery":
                element = {
                    "component": comp,
                    "kind": "vsource",
                    "model": "ideal_voltage_source",
                    "n1": n1,
                    "n2": n2,
                    "positive_node": n2,
                    "negative_node": n1,
                    "value": value,
                }
                source_components.append(element)
                elements.append(element)
                continue

            if comp_type in ("acsource", "ac source", "ac"):
                source_value = self._ac_source_value(comp, mode)
                element = {
                    "component": comp,
                    "kind": "acsource",
                    "model": "sine_voltage_source" if mode == "transient" else "ac_source_dc_operating_point",
                    "n1": n1,
                    "n2": n2,
                    "positive_node": n2,
                    "negative_node": n1,
                    "value": source_value,
                    "amplitude": value,
                    "frequency": self._safe_float(getattr(comp, "frequency", 60.0), default=60.0),
                    "phase": self._safe_float(getattr(comp, "phase", 0.0), default=0.0),
                }
                source_components.append(element)
                elements.append(element)
                continue

            if comp_type in ("current", "currentsource", "current source"):
                elements.append({
                    "component": comp,
                    "kind": "isource",
                    "model": "ideal_current_source",
                    "n1": n1,
                    "n2": n2,
                    "positive_node": n1,
                    "negative_node": n2,
                    "value": value,
                })
                continue

            if comp_type in ("diode", "led"):
                default_drop = 2.0 if comp_type == "led" else 0.7
                forward_drop = abs(value) if abs(value) > 1e-12 else default_drop
                is_on = bool(diode_modes.get(comp_id, False))

                element = {
                    "component": comp,
                    "kind": "diode_on" if is_on else "diode_off",
                    "model": "constant_drop" if is_on else "open_circuit",
                    "n1": n1,
                    "n2": n2,
                    "positive_node": n1,
                    "negative_node": n2,
                    "value": forward_drop,
                    "mode": "ON" if is_on else "OFF",
                    "is_led": comp_type == "led",
                }

                if is_on:
                    source_components.append(element)

                elements.append(element)
                continue

            if comp_type == "switch":
                closed = value >= 0.5
                if closed:
                    elements.append({
                        "component": comp,
                        "kind": "switch_closed",
                        "model": "closed_switch",
                        "n1": n1,
                        "n2": n2,
                        "value": 0.01,
                        "conductance": 100.0,
                        "mode": "CLOSED",
                    })
                else:
                    elements.append({
                        "component": comp,
                        "kind": "switch_open",
                        "model": "open_switch",
                        "n1": n1,
                        "n2": n2,
                        "value": 0.0,
                        "mode": "OPEN",
                    })
                continue

            if comp_type == "transistor":
                n3 = self.node_manager.get_node_index(comp_id, 3)
                if n3 < 0:
                    continue

                is_on = bool(diode_modes.get(comp_id, False))
                element = {
                    "component": comp,
                    "kind": "transistor_on" if is_on else "transistor_off",
                    "model": "npn_switch",
                    "n1": n1,
                    "n2": n2,
                    "n3": n3,
                    "collector_node": n1,
                    "base_node": n2,
                    "emitter_node": n3,
                    "value": max(abs(value), 1.0),
                    "conductance": 1.0 / max(50.0 / max(abs(value), 1.0), 1.0),
                    "mode": "ON" if is_on else "OFF",
                }
                elements.append(element)
                continue

            if comp_type == "capacitor":
                capacitance_farads = max(abs(value), 1e-12) * 1e-6

                if mode == "transient":
                    state = self.capacitor_states.get(comp_id, CapacitorState())
                    conductance = capacitance_farads / time_step
                    history_voltage = float(state.voltage)

                    elements.append({
                        "component": comp,
                        "kind": "capacitor_transient",
                        "model": "backward_euler",
                        "n1": n1,
                        "n2": n2,
                        "value": capacitance_farads,
                        "conductance": conductance,
                        "history_voltage": history_voltage,
                        "history_current": float(state.current),
                    })
                else:
                    elements.append({
                        "component": comp,
                        "kind": "capacitor_dc",
                        "model": "open_circuit",
                        "n1": n1,
                        "n2": n2,
                        "value": capacitance_farads,
                    })

        for index, element in enumerate(source_components):
            element["source_index"] = self.last_num_nodes + index

        self.last_num_voltage_sources = len(source_components)

        return {
            "elements": elements,
            "source_components": source_components,
            "num_nodes": self.last_num_nodes,
            "num_voltage_sources": len(source_components),
            "mode": mode,
            "time_step": time_step,
        }

    # ==========================================================
    # MATRIX BUILD / STAMPING
    # ==========================================================
    def build_matrix(self, plan):
        try:
            num_nodes = plan["num_nodes"]
            num_v_sources = plan["num_voltage_sources"]
            size = num_nodes + num_v_sources

            A = np.zeros((size, size), dtype=float)
            Z = np.zeros(size, dtype=float)

            for element in plan["elements"]:
                kind = element["kind"]
                n1 = element["n1"]
                n2 = element["n2"]

                if kind == "resistor":
                    self._stamp_conductance(A, n1, n2, element["conductance"])

                elif kind in ("vsource", "acsource"):
                    self._stamp_voltage_source(
                        A,
                        Z,
                        element.get("positive_node", n1),
                        element.get("negative_node", n2),
                        element["value"],
                        element["source_index"],
                    )

                elif kind == "diode_on":
                    self._stamp_voltage_source(
                        A,
                        Z,
                        element.get("positive_node", n1),
                        element.get("negative_node", n2),
                        element["value"],
                        element["source_index"],
                    )

                elif kind == "isource":
                    self._stamp_current_source(Z, n1, n2, element["value"])

                elif kind == "switch_closed":
                    self._stamp_conductance(A, n1, n2, element["conductance"])

                elif kind == "transistor_on":
                    self._stamp_conductance(
                        A,
                        element["collector_node"],
                        element["emitter_node"],
                        element["conductance"],
                    )

                elif kind == "capacitor_transient":
                    self._stamp_conductance(A, n1, n2, element["conductance"])
                    history_current = element["conductance"] * element["history_voltage"]
                    self._stamp_current_source(Z, n1, n2, history_current)

            self._stamp_ground_reference(A, Z, 0)

            self.last_matrix_A = A.copy()
            self.last_vector_Z = Z.copy()
            self.last_diagnostics = {
                "matrix": self._matrix_diagnostics(A, Z),
            }

            return {
                "success": True,
                "A": A,
                "Z": Z,
                "message": "Matrix built successfully.",
            }

        except Exception as exc:
            return self._fail(f"Matrix build failed: {exc}")

    def _stamp_conductance(self, A, n1, n2, conductance):
        if n1 == n2:
            return

        A[n1, n1] += conductance
        A[n2, n2] += conductance
        A[n1, n2] -= conductance
        A[n2, n1] -= conductance

    def _stamp_voltage_source(self, A, Z, positive_node, negative_node, value, source_index):
        A[positive_node, source_index] += 1.0
        A[negative_node, source_index] -= 1.0
        A[source_index, positive_node] += 1.0
        A[source_index, negative_node] -= 1.0
        Z[source_index] += value

    def _stamp_current_source(self, Z, n1, n2, current):
        Z[n1] -= current
        Z[n2] += current

    def _stamp_ground_reference(self, A, Z, ground_index):
        A[ground_index, :] = 0.0
        A[:, ground_index] = 0.0
        A[ground_index, ground_index] = 1.0
        Z[ground_index] = 0.0

    def _ac_source_value(self, comp, mode):
        amplitude = self._safe_float(getattr(comp, "value", 0.0), default=0.0)
        if mode != "transient":
            return 0.0

        if hasattr(comp, "get_voltage_at"):
            try:
                return float(comp.get_voltage_at(self.current_time))
            except Exception:
                pass

        frequency = self._safe_float(getattr(comp, "frequency", 60.0), default=60.0)
        phase = self._safe_float(getattr(comp, "phase", 0.0), default=0.0)
        return amplitude * np.sin((2.0 * np.pi * frequency * self.current_time) + np.deg2rad(phase))

    def _solve_linear_system(self, A, Z, allow_regularization=False):
        try:
            X = np.linalg.solve(A, Z)
            self.last_solution_X = X.copy()
            return {"success": True, "X": X}
        except np.linalg.LinAlgError:
            if allow_regularization:
                try:
                    regularization = 1e-12
                    X = np.linalg.solve(A + np.eye(A.shape[0]) * regularization, Z)
                    self.last_solution_X = X.copy()
                    return {"success": True, "X": X, "regularized": True}
                except np.linalg.LinAlgError:
                    pass

            diagnostics = {
                "matrix": self._matrix_diagnostics(A, Z),
                "floating_nodes": self._detect_zero_rows(A),
            }
            return self._fail(
                "Mathematical Error: Singular Matrix. Check floating nodes, ground, wires, or open branches.",
                diagnostics=diagnostics,
            )

    # ==========================================================
    # STEP 4 DIAGNOSTICS
    # ==========================================================
    def _check_floating_nodes(self, plan):
        floating_nodes = self._find_floating_solver_nodes(plan)
        if not floating_nodes:
            return {"success": True, "floating_nodes": []}

        labels = ", ".join(f"Node {item['node']}" for item in floating_nodes)
        return {
            "success": False,
            "floating_nodes": floating_nodes,
            "message": f"Floating node detected: {labels}. Connect this network to ground through a real DC path.",
        }

    def _find_floating_solver_nodes(self, plan):
        num_nodes = int(plan.get("num_nodes", 0))
        if num_nodes <= 1:
            return []

        adjacency = {index: set() for index in range(num_nodes)}
        active_kinds = {
            "resistor",
            "vsource",
            "acsource",
            "isource",
            "diode_on",
            "switch_closed",
            "transistor_on",
            "capacitor_transient",
            "ground",
        }

        for element in plan.get("elements", []):
            if element.get("kind") not in active_kinds:
                continue

            pairs = [(element.get("n1", -1), element.get("n2", -1))]
            if element.get("kind") == "transistor_on":
                pairs = [(element.get("collector_node", -1), element.get("emitter_node", -1))]

            for node_a, node_b in pairs:
                n1 = int(node_a)
                n2 = int(node_b)
                if n1 < 0 or n2 < 0 or n1 == n2:
                    continue
                adjacency.setdefault(n1, set()).add(n2)
                adjacency.setdefault(n2, set()).add(n1)

        visited = set()
        stack = [0]
        while stack:
            node = stack.pop()
            if node in visited:
                continue
            visited.add(node)
            stack.extend(adjacency.get(node, set()) - visited)

        node_table = self._solver_node_table_by_index()
        floating = []
        for node in range(1, num_nodes):
            if node in visited:
                continue
            table_item = node_table.get(node, {})
            floating.append({
                "node": node,
                "root": table_item.get("root"),
                "pins": list(table_item.get("nodes", [])),
            })

        return floating

    def _matrix_diagnostics(self, A, Z):
        if A is None or Z is None:
            return {
                "rows": 0,
                "cols": 0,
                "rank": 0,
                "condition_number": None,
                "is_square": False,
                "zero_rows": [],
                "rhs_norm": 0.0,
            }

        diagnostics = {
            "rows": int(A.shape[0]),
            "cols": int(A.shape[1]),
            "rank": 0,
            "condition_number": None,
            "is_square": bool(A.shape[0] == A.shape[1]),
            "zero_rows": self._detect_zero_rows(A),
            "rhs_norm": round(float(np.linalg.norm(Z)), 12),
        }

        try:
            diagnostics["rank"] = int(np.linalg.matrix_rank(A))
        except Exception:
            diagnostics["rank"] = 0

        try:
            condition_number = float(np.linalg.cond(A))
            if np.isfinite(condition_number):
                diagnostics["condition_number"] = round(condition_number, 6)
        except Exception:
            diagnostics["condition_number"] = None

        return diagnostics

    def _detect_zero_rows(self, A, tolerance=1e-12):
        zero_rows = []
        for index, row in enumerate(A):
            if float(np.linalg.norm(row, ord=1)) <= tolerance:
                zero_rows.append(int(index))
        return zero_rows

    def _build_kcl_analysis(self, X):
        if self.last_matrix_A is None or self.last_vector_Z is None:
            return {}

        residual = np.matmul(self.last_matrix_A, X) - self.last_vector_Z
        node_residuals = residual[:self.last_num_nodes]
        max_error = float(np.max(np.abs(node_residuals))) if len(node_residuals) else 0.0

        return {
            "max_node_residual": round(max_error, 12),
            "node_residuals": [round(float(value), 12) for value in node_residuals],
            "passed": bool(max_error <= 1e-7),
        }

    def _build_voltage_analysis(self, node_voltages, component_results):
        node_table = self._solver_node_table_by_index()
        nodes = []
        for index, voltage in enumerate(node_voltages):
            table_item = node_table.get(index, {})
            nodes.append({
                "node": int(index),
                "voltage": round(float(voltage), 6),
                "is_ground": index == 0,
                "root": table_item.get("root"),
                "pins": list(table_item.get("nodes", [])),
            })

        drops = []
        for item in component_results:
            drops.append({
                "id": item.get("id"),
                "type": item.get("type"),
                "from_node": item.get("node1_index"),
                "to_node": item.get("node2_index"),
                "voltage_drop": item.get("v_drop", 0.0),
            })

        return {
            "nodes": nodes,
            "component_drops": drops,
        }

    def _build_current_analysis(self, component_results):
        entries = []
        total_abs_current = 0.0

        for item in component_results:
            current = self._safe_float(item.get("current", 0.0))
            total_abs_current += abs(current)
            direction = "pin1_to_pin2"
            if current < 0:
                direction = "pin2_to_pin1"
            elif abs(current) < 1e-12:
                direction = "no_current"

            entries.append({
                "id": item.get("id"),
                "type": item.get("type"),
                "current": round(current, 9),
                "magnitude": round(abs(current), 9),
                "direction": direction,
                "from_node": item.get("node1_index") if current >= 0 else item.get("node2_index"),
                "to_node": item.get("node2_index") if current >= 0 else item.get("node1_index"),
            })

        return {
            "total_absolute_current": round(total_abs_current, 9),
            "components": entries,
        }

    def _build_error_detection(self, plan, X, component_results):
        issues = []
        matrix_info = self._matrix_diagnostics(self.last_matrix_A, self.last_vector_Z)
        kcl_info = self._build_kcl_analysis(X)
        floating_nodes = self._find_floating_solver_nodes(plan)

        if matrix_info["rank"] < matrix_info["rows"]:
            issues.append("Matrix is rank deficient.")

        condition_number = matrix_info.get("condition_number")
        if condition_number is not None and condition_number > 1e12:
            issues.append(f"Matrix is poorly conditioned ({condition_number}).")

        if not kcl_info.get("passed", True):
            issues.append(f"KCL residual is high ({kcl_info.get('max_node_residual')}).")

        for item in component_results:
            voltage = abs(self._safe_float(item.get("v_drop", 0.0)))
            current = abs(self._safe_float(item.get("current", 0.0)))
            power = abs(self._safe_float(item.get("power", 0.0)))
            comp_id = item.get("id")

            if not np.isfinite(voltage) or not np.isfinite(current) or not np.isfinite(power):
                issues.append(f"Non-finite result detected on component {comp_id}.")
            if current > 1000:
                issues.append(f"Very high current detected on component {comp_id}: {current:.6f} A.")
            if power > 10000:
                issues.append(f"Very high power detected on component {comp_id}: {power:.6f} W.")

        return {
            "issues": issues,
            "floating_nodes": floating_nodes,
            "matrix": matrix_info,
            "kcl": kcl_info,
            "passed": len(issues) == 0 and len(floating_nodes) == 0,
        }

    def _solver_node_table_by_index(self):
        if self.node_manager is None:
            return {}

        try:
            table = self.node_manager.get_solver_node_table()
        except Exception:
            return {}

        return {int(item.get("index", -1)): item for item in table}

    # ==========================================================
    # COMPONENT STATES
    # ==========================================================
    def _evaluate_diode_modes(self, X):
        node_voltages = X[:self.last_num_nodes]
        diode_modes = {}

        for comp in self.components:
            comp_type = self._get_component_type(comp)

            comp_id = getattr(comp, "id", None)

            if comp_type in ("diode", "led"):
                n1 = self.node_manager.get_node_index(comp_id, 1)
                n2 = self.node_manager.get_node_index(comp_id, 2)

                if n1 < 0 or n2 < 0:
                    diode_modes[comp_id] = False
                    continue

                default_drop = 2.0 if comp_type == "led" else 0.7
                forward_drop = abs(self._safe_float(getattr(comp, "value", default_drop), default=default_drop))
                bias = float(node_voltages[n1] - node_voltages[n2])
                diode_modes[comp_id] = bias + self.options.diode_threshold >= forward_drop
                continue

            if comp_type == "transistor":
                base = self.node_manager.get_node_index(comp_id, 2)
                emitter = self.node_manager.get_node_index(comp_id, 3)
                if base < 0 or emitter < 0:
                    diode_modes[comp_id] = False
                    continue

                bias = float(node_voltages[base] - node_voltages[emitter])
                diode_modes[comp_id] = bias >= 0.65

        return diode_modes

    def _commit_capacitor_state(self, step_result):
        for comp_result in step_result.get("component_results", []):
            if str(comp_result.get("type", "")).strip().lower() != "capacitor":
                continue

            comp_id = comp_result.get("id")
            self.capacitor_states[comp_id] = CapacitorState(
                voltage=float(comp_result.get("v_drop", 0.0)),
                current=float(comp_result.get("current", 0.0)),
            )

    # ==========================================================
    # RESULT PROCESSING
    # ==========================================================
    def _build_result(self, X, plan, mode, time_step, transient_snapshots):
        num_nodes = plan["num_nodes"]
        node_voltages = X[:num_nodes]
        component_results = []

        total_power_generated = 0.0
        total_power_consumed = 0.0
        source_currents = self._extract_source_currents(X, plan)

        for element in plan["elements"]:
            comp = element["component"]
            comp_id = getattr(comp, "id", None)
            n1 = element["n1"]
            n2 = element["n2"]

            v1 = float(node_voltages[n1])
            v2 = float(node_voltages[n2])
            v_drop = v1 - v2

            current = 0.0
            power = 0.0
            extra = {}
            raw_value = self._safe_float(getattr(comp, "value", 0.0), default=0.0)

            if element["kind"] == "resistor":
                resistance = element["value"]
                current = v_drop / resistance
                power = v_drop * current
                extra["model"] = element.get("model", "ohmic")

            elif element["kind"] in ("vsource", "acsource"):
                current = self._source_current_in_pin_order(
                    source_currents.get(comp_id, 0.0),
                    element,
                )
                power = v_drop * current
                extra["model"] = element.get("model", "ideal_voltage_source")
                if element["kind"] == "acsource":
                    extra["amplitude"] = round(float(element.get("amplitude", 0.0)), 6)
                    extra["frequency"] = round(float(element.get("frequency", 0.0)), 6)
                    extra["phase"] = round(float(element.get("phase", 0.0)), 6)
                    extra["instant_voltage"] = round(float(element.get("value", 0.0)), 6)

            elif element["kind"] == "diode_on":
                current = self._source_current_in_pin_order(
                    source_currents.get(comp_id, 0.0),
                    element,
                )
                power = v_drop * current
                extra["mode"] = "ON"
                extra["model"] = "constant_drop"

            elif element["kind"] == "diode_off":
                current = 0.0
                power = 0.0
                extra["mode"] = "OFF"
                extra["model"] = "open_circuit"
                if element.get("is_led"):
                    extra["emitting"] = False

            elif element["kind"] == "isource":
                current = float(element["value"])
                power = v_drop * current
                extra["model"] = "ideal_current_source"
                extra["direction"] = "pin1_to_pin2"

            elif element["kind"] == "switch_closed":
                resistance = element["value"]
                current = v_drop / resistance
                power = v_drop * current
                extra["mode"] = "CLOSED"
                extra["model"] = "closed_switch"

            elif element["kind"] == "switch_open":
                current = 0.0
                power = 0.0
                extra["mode"] = "OPEN"
                extra["model"] = "open_switch"

            elif element["kind"] == "transistor_on":
                resistance = 1.0 / max(float(element["conductance"]), 1e-12)
                ce_voltage = float(node_voltages[element["collector_node"]] - node_voltages[element["emitter_node"]])
                v_drop = ce_voltage
                current = ce_voltage / resistance
                power = ce_voltage * current
                extra["mode"] = "ON"
                extra["model"] = "npn_switch"
                extra["collector_node"] = int(element["collector_node"])
                extra["base_node"] = int(element["base_node"])
                extra["emitter_node"] = int(element["emitter_node"])
                extra["v_be"] = round(float(node_voltages[element["base_node"]] - node_voltages[element["emitter_node"]]), 6)
                extra["v_ce"] = round(ce_voltage, 6)

            elif element["kind"] == "transistor_off":
                ce_voltage = float(node_voltages[element["collector_node"]] - node_voltages[element["emitter_node"]])
                v_drop = ce_voltage
                current = 0.0
                power = 0.0
                extra["mode"] = "OFF"
                extra["model"] = "npn_switch"
                extra["collector_node"] = int(element["collector_node"])
                extra["base_node"] = int(element["base_node"])
                extra["emitter_node"] = int(element["emitter_node"])
                extra["v_be"] = round(float(node_voltages[element["base_node"]] - node_voltages[element["emitter_node"]]), 6)
                extra["v_ce"] = round(ce_voltage, 6)

            elif element["kind"] == "capacitor_transient":
                previous_voltage = float(element["history_voltage"])
                conductance = float(element["conductance"])
                current = conductance * (v_drop - previous_voltage)
                power = v_drop * current
                extra["mode"] = "TRANSIENT"
                extra["model"] = "backward_euler"
                extra["time_step"] = time_step
                extra["previous_voltage"] = round(previous_voltage, 9)

            elif element["kind"] == "capacitor_dc":
                current = 0.0
                power = 0.0
                extra["mode"] = "DC"
                extra["model"] = "open_circuit"

            elif element["kind"] == "ground":
                current = 0.0
                power = 0.0
                raw_value = 0.0
                extra["mode"] = "REFERENCE"
                extra["model"] = "reference_node"

            if element.get("is_led") and element["kind"] == "diode_on":
                extra["emitting"] = abs(float(current)) > 1e-9

            if power >= 0:
                total_power_consumed += abs(power)
            else:
                total_power_generated += abs(power)

            component_results.append({
                "id": comp_id,
                "type": str(getattr(comp, "comp_type", getattr(comp, "type", "Unknown"))),
                "node1_index": int(n1),
                "node2_index": int(n2),
                "node1_voltage": round(v1, 6),
                "node2_voltage": round(v2, 6),
                "v_drop": round(v_drop, 6),
                "current": round(float(current), 6),
                "power": round(float(power), 6),
                "value": raw_value,
                **extra,
            })

        result = {
            "success": True,
            "message": "DC analysis successful." if mode == "dc" else "Transient analysis successful.",
            "analysis_mode": mode,
            "node_voltages": [round(float(v), 6) for v in node_voltages],
            "component_results": component_results,
            "voltage_analysis": self._build_voltage_analysis(node_voltages, component_results),
            "current_analysis": self._build_current_analysis(component_results),
            "kcl_analysis": self._build_kcl_analysis(X),
            "error_detection": self._build_error_detection(plan, X, component_results),
            "power_balance": {
                "generated": round(float(total_power_generated), 6),
                "consumed": round(float(total_power_consumed), 6),
            },
            "transient_snapshots": transient_snapshots,
            "solver_info": {
                "method": "MNA + KCL",
                "analysis_mode": mode,
                "num_nodes": int(num_nodes),
                "num_voltage_sources": int(plan["num_voltage_sources"]),
                "matrix_size": int(len(X)),
                "time_step": time_step,
                "transient_steps": len(transient_snapshots),
                "matrix": self._matrix_diagnostics(self.last_matrix_A, self.last_vector_Z),
            },
        }

        self.results = result
        self.last_error = ""
        return result

    def _extract_source_currents(self, X, plan):
        source_currents = {}

        for element in plan["source_components"]:
            comp_id = getattr(element["component"], "id", None)
            source_index = element["source_index"]
            source_currents[comp_id] = float(X[source_index])

        return source_currents

    def _source_current_in_pin_order(self, source_current, element):
        positive_node = element.get("positive_node", element.get("n1"))
        negative_node = element.get("negative_node", element.get("n2"))

        if positive_node == element.get("n1") and negative_node == element.get("n2"):
            return float(source_current)

        if positive_node == element.get("n2") and negative_node == element.get("n1"):
            return -float(source_current)

        return float(source_current)

    # ==========================================================
    # HELPERS / DEBUG
    # ==========================================================
    def _get_component_type(self, comp):
        raw = getattr(comp, "comp_type", getattr(comp, "type", "unknown"))
        return str(raw).strip().lower()

    def _safe_float(self, value, default=0.0):
        try:
            return float(value)
        except Exception:
            return float(default)

    def get_last_matrix(self):
        return self.last_matrix_A

    def get_last_vector(self):
        return self.last_vector_Z

    def get_last_solution(self):
        return self.last_solution_X

    def get_debug_summary(self):
        return {
            "components_count": len(self.components),
            "wires_count": len(self.wires),
            "num_nodes": self.last_num_nodes,
            "num_voltage_sources": self.last_num_voltage_sources,
            "elements_count": self.last_elements_count,
            "has_node_manager": self.node_manager is not None,
            "has_circuit_manager": self.circuit_manager is not None,
            "last_success": self.results.get("success", False),
            "last_message": self.results.get("message", ""),
            "analysis_mode": self.results.get("analysis_mode", self.options.analysis_mode),
            "last_error": self.last_error,
        }

    def print_debug_summary(self):
        info = self.get_debug_summary()
        print("============== SOLVER DEBUG ==============")
        print(f"Components Count      : {info['components_count']}")
        print(f"Wires Count           : {info['wires_count']}")
        print(f"Nodes Count           : {info['num_nodes']}")
        print(f"Voltage Sources Count : {info['num_voltage_sources']}")
        print(f"Elements Count        : {info['elements_count']}")
        print(f"Has NodeManager       : {info['has_node_manager']}")
        print(f"Has CircuitManager    : {info['has_circuit_manager']}")
        print(f"Last Success          : {info['last_success']}")
        print(f"Last Message          : {info['last_message']}")
        print(f"Analysis Mode         : {info['analysis_mode']}")
        print(f"Last Error            : {info['last_error']}")
        print("==========================================")

    def print_last_matrix(self):
        if self.last_matrix_A is None:
            print("No matrix built yet.")
            return
        print("A matrix:")
        print(self.last_matrix_A)

    def print_last_vector(self):
        if self.last_vector_Z is None:
            print("No vector built yet.")
            return
        print("Z vector:")
        print(self.last_vector_Z)

    def print_last_solution(self):
        if self.last_solution_X is None:
            print("No solution available yet.")
            return
        print("X solution:")
        print(self.last_solution_X)

    def _fail(self, message, diagnostics=None):
        self.last_error = str(message)
        self.results = {
            "success": False,
            "message": str(message),
        }
        if diagnostics is not None:
            self.results["diagnostics"] = diagnostics
            self.last_diagnostics = diagnostics
        return self.results

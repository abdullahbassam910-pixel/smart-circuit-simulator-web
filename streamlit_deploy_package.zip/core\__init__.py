"""Core package for the Streamlit deployment build."""

﻿class CircuitValidator:
    """
    SMART CIRCUIT SIMULATOR PRO v6.3 ULTRA
    Circuit Validation Engine

    Responsibilities
    ----------------
    - Validate circuit before simulation
    - Detect missing ground
    - Detect isolated / incomplete connections
    - Detect empty circuit
    - Detect unsupported or suspicious values
    - Prepare readable validation report
    """

    def __init__(self):
        self.last_result = None
        self.last_error = ""

    # ==========================================================
    # INTERNAL HELPERS
    # ==========================================================
    def _safe_comp_type(self, comp):
        return str(getattr(comp, "comp_type", getattr(comp, "type", "unknown"))).strip().lower()

    def _safe_comp_name(self, comp):
        return str(getattr(comp, "comp_type", getattr(comp, "type", "Unknown")))

    def _safe_comp_id(self, comp):
        return getattr(comp, "id", "unknown")

    def _safe_value(self, comp, default=0.0):
        try:
            return float(getattr(comp, "value", default))
        except Exception:
            return float(default)

    def _is_deleted(self, obj):
        return bool(getattr(obj, "deleted", False))

    def _active_components(self, components):
        return [c for c in (components or []) if c is not None and not self._is_deleted(c)]

    def _active_wires(self, wires):
        return [w for w in (wires or []) if w is not None and not self._is_deleted(w)]

    def _component_wire_count_map(self, components, wires):
        wire_count = {self._safe_comp_id(comp): 0 for comp in components}

        for wire in wires:
            start_comp = getattr(wire, "start_comp", None)
            end_comp = getattr(wire, "end_comp", None)

            if start_comp is not None:
                comp_id = self._safe_comp_id(start_comp)
                if comp_id in wire_count:
                    wire_count[comp_id] += 1

            if end_comp is not None:
                comp_id = self._safe_comp_id(end_comp)
                if comp_id in wire_count:
                    wire_count[comp_id] += 1

        return wire_count

    def _make_pin_name(self, comp, pin):
        return f"{self._safe_comp_id(comp)}_p{pin}"

    def _pin_count(self, comp):
        try:
            return max(1, int(getattr(comp, "PIN_COUNT", getattr(comp, "pin_count", 2))))
        except Exception:
            return 2

    def _detect_floating_networks(self, components, wires):
        parent = {}

        def find(node):
            parent.setdefault(node, node)
            if parent[node] != node:
                parent[node] = find(parent[node])
            return parent[node]

        def union(a, b):
            root_a = find(a)
            root_b = find(b)
            if root_a != root_b:
                parent[root_b] = root_a

        for comp in components:
            pin1 = self._make_pin_name(comp, 1)
            pin2 = self._make_pin_name(comp, 2)
            for pin_number in range(1, self._pin_count(comp) + 1):
                find(self._make_pin_name(comp, pin_number))

            comp_type = self._safe_comp_type(comp)
            if comp_type in ("ground", "gnd", "resistor", "battery", "acsource", "ac source", "ac", "diode", "led"):
                union(pin1, pin2)
            if comp_type == "switch" and self._safe_value(comp, 0.0) >= 0.5:
                union(pin1, pin2)

        for wire in wires:
            start_comp = getattr(wire, "start_comp", None)
            end_comp = getattr(wire, "end_comp", None)
            start_pin = getattr(wire, "start_pin", None)
            end_pin = getattr(wire, "end_pin", None)

            if start_comp is None or end_comp is None or start_pin is None or end_pin is None:
                continue

            union(
                f"{self._safe_comp_id(start_comp)}_p{start_pin}",
                f"{self._safe_comp_id(end_comp)}_p{end_pin}",
            )

        ground_roots = set()
        for comp in components:
            if self._safe_comp_type(comp) in ("ground", "gnd"):
                ground_roots.add(find(self._make_pin_name(comp, 1)))
                ground_roots.add(find(self._make_pin_name(comp, 2)))

        groups = {}
        for node in list(parent):
            groups.setdefault(find(node), []).append(node)

        floating = []
        for root, pins in groups.items():
            if root in ground_roots:
                continue

            component_ids = sorted({pin.rsplit("_p", 1)[0] for pin in pins})
            floating.append({
                "root": root,
                "pins": sorted(pins),
                "component_ids": component_ids,
            })

        return floating

    # ==========================================================
    # VALIDATION CORE
    # ==========================================================
    def validate(self, components, wires):
        """
        Main validation method.
        Returns a structured dict result.
        """
        components = self._active_components(components)
        wires = self._active_wires(wires)

        errors = []
        warnings = []
        info = []

        if not components:
            errors.append("Circuit is empty. Add at least one component.")
            return self._build_result(False, errors, warnings, info)

        component_types = [self._safe_comp_type(comp) for comp in components]
        wire_count = self._component_wire_count_map(components, wires)

        ground_components = [comp for comp in components if self._safe_comp_type(comp) in ("ground", "gnd")]
        battery_components = [comp for comp in components if self._safe_comp_type(comp) == "battery"]
        ac_components = [
            comp for comp in components
            if self._safe_comp_type(comp) in ("acsource", "ac source", "ac")
        ]
        current_components = [
            comp for comp in components
            if self._safe_comp_type(comp) in ("current", "currentsource", "current source")
        ]
        resistor_components = [comp for comp in components if self._safe_comp_type(comp) == "resistor"]
        diode_components = [comp for comp in components if self._safe_comp_type(comp) == "diode"]
        led_components = [comp for comp in components if self._safe_comp_type(comp) == "led"]
        switch_components = [comp for comp in components if self._safe_comp_type(comp) == "switch"]
        transistor_components = [comp for comp in components if self._safe_comp_type(comp) == "transistor"]
        capacitor_components = [comp for comp in components if self._safe_comp_type(comp) == "capacitor"]

        # ------------------------------------------------------
        # REQUIRED ELEMENTS
        # ------------------------------------------------------
        if not ground_components:
            errors.append("Ground is missing. Add a Ground component before solving.")

        if not wires:
            warnings.append("No wires found. Components are not connected.")

        # ------------------------------------------------------
        # CONNECTION CHECKS
        # ------------------------------------------------------
        isolated_components = []
        weakly_connected_components = []

        for comp in components:
            comp_type = self._safe_comp_type(comp)
            comp_id = self._safe_comp_id(comp)
            count = wire_count.get(comp_id, 0)

            if count == 0:
                isolated_components.append(f"{self._safe_comp_name(comp)} ({comp_id})")
            elif count == 1 and comp_type not in ("ground", "gnd"):
                weakly_connected_components.append(f"{self._safe_comp_name(comp)} ({comp_id})")

        if isolated_components:
            errors.append(
                "Isolated components detected: " + ", ".join(isolated_components)
            )

        if weakly_connected_components:
            warnings.append(
                "Possibly incomplete connections: " + ", ".join(weakly_connected_components)
            )

        floating_networks = self._detect_floating_networks(components, wires)
        if ground_components and floating_networks:
            readable = []
            for network in floating_networks:
                readable.append(
                    f"{network['root']} ({', '.join(network['component_ids'])})"
                )
            errors.append(
                "Floating node/network detected: "
                + "; ".join(readable)
                + ". Add a ground path or connect the network into the grounded circuit."
            )

        # ------------------------------------------------------
        # VALUE CHECKS
        # ------------------------------------------------------
        for comp in resistor_components:
            value = self._safe_value(comp, 0.0)
            comp_id = self._safe_comp_id(comp)
            if value <= 0:
                errors.append(f"Resistor ({comp_id}) has invalid value: {value}. Must be > 0 ohms.")
            elif value < 1e-6:
                warnings.append(f"Resistor ({comp_id}) is extremely small and may cause high current.")

        for comp in battery_components:
            value = self._safe_value(comp, 0.0)
            comp_id = self._safe_comp_id(comp)
            if value == 0:
                warnings.append(f"Battery ({comp_id}) has 0V value.")
            if abs(value) > 1000:
                warnings.append(f"Battery ({comp_id}) has unusually large voltage: {value} V.")

        for comp in ac_components:
            value = self._safe_value(comp, 0.0)
            comp_id = self._safe_comp_id(comp)
            if value == 0:
                warnings.append(f"AC Source ({comp_id}) has 0V amplitude.")
            if abs(value) > 1000:
                warnings.append(f"AC Source ({comp_id}) has unusually large amplitude: {value} Vpk.")

        for comp in current_components:
            value = self._safe_value(comp, 0.0)
            comp_id = self._safe_comp_id(comp)
            if value == 0:
                warnings.append(f"Current source ({comp_id}) has 0A value.")
            if abs(value) > 100:
                warnings.append(f"Current source ({comp_id}) has unusually large current: {value} A.")

        for comp in diode_components:
            value = self._safe_value(comp, 0.7)
            comp_id = self._safe_comp_id(comp)
            if value <= 0:
                warnings.append(f"Diode ({comp_id}) forward drop is non-positive: {value} V.")

        for comp in led_components:
            value = self._safe_value(comp, 2.0)
            comp_id = self._safe_comp_id(comp)
            if value <= 0:
                warnings.append(f"LED ({comp_id}) forward drop is non-positive: {value} V.")

        for comp in switch_components:
            value = self._safe_value(comp, 0.0)
            comp_id = self._safe_comp_id(comp)
            if value not in (0.0, 1.0):
                warnings.append(f"Switch ({comp_id}) uses threshold mode: value >= 0.5 is closed.")

        for comp in transistor_components:
            value = self._safe_value(comp, 100.0)
            comp_id = self._safe_comp_id(comp)
            if value <= 0:
                warnings.append(f"Transistor ({comp_id}) beta should be positive.")

        for comp in capacitor_components:
            value = self._safe_value(comp, 0.0)
            comp_id = self._safe_comp_id(comp)
            if value <= 0:
                errors.append(f"Capacitor ({comp_id}) has invalid value: {value}. Must be > 0 uF.")
            elif value > 1_000_000:
                warnings.append(f"Capacitor ({comp_id}) value is unusually large: {value} uF.")

        # ------------------------------------------------------
        # WIRE CHECKS
        # ------------------------------------------------------
        invalid_wires = []

        for wire in wires:
            start_comp = getattr(wire, "start_comp", None)
            end_comp = getattr(wire, "end_comp", None)
            start_pin = getattr(wire, "start_pin", None)
            end_pin = getattr(wire, "end_pin", None)
            wire_id = getattr(wire, "id", "unknown")

            if start_comp is None or end_comp is None:
                invalid_wires.append(f"Wire ({wire_id}) has missing endpoint.")
                continue

            if start_pin is None or end_pin is None:
                invalid_wires.append(f"Wire ({wire_id}) has missing pin definition.")
                continue

            if start_comp == end_comp and start_pin == end_pin:
                warnings.append(f"Wire ({wire_id}) loops back to the exact same pin.")

        if invalid_wires:
            errors.extend(invalid_wires)

        # ------------------------------------------------------
        # CIRCUIT-LEVEL NOTES
        # ------------------------------------------------------
        info.append(f"Components count: {len(components)}")
        info.append(f"Wires count: {len(wires)}")
        info.append(f"Ground count: {len(ground_components)}")
        info.append(f"Available component types: {', '.join(sorted(set(component_types)))}")

        if len(ground_components) > 1:
            warnings.append("Multiple ground components detected. Ensure they are intended.")

        source_components = battery_components + ac_components + current_components
        load_components = resistor_components + capacitor_components + diode_components + led_components + switch_components + transistor_components
        if source_components and not load_components:
            warnings.append("Circuit contains a source but no passive/active load components.")

        success = len(errors) == 0
        return self._build_result(success, errors, warnings, info)

    def run_validation(self, components, wires):
        """
        Alias for validate().
        """
        return self.validate(components, wires)

    def analyze(self, components, wires):
        """
        Alias for validate().
        """
        return self.validate(components, wires)

    # ==========================================================
    # RESULT / REPORT
    # ==========================================================
    def _build_result(self, success, errors, warnings, info):
        result = {
            "success": bool(success),
            "errors": list(errors),
            "warnings": list(warnings),
            "info": list(info),
            "message": "Validation passed." if success else "Validation failed.",
        }
        self.last_result = result
        self.last_error = ""
        return result

    def get_last_result(self):
        return self.last_result

    def has_result(self):
        return self.last_result is not None

    def get_errors(self):
        if not self.last_result:
            return []
        return list(self.last_result.get("errors", []))

    def get_warnings(self):
        if not self.last_result:
            return []
        return list(self.last_result.get("warnings", []))

    def get_info(self):
        if not self.last_result:
            return []
        return list(self.last_result.get("info", []))

    def get_message(self):
        if not self.last_result:
            return "No validation run."
        return self.last_result.get("message", "No message available.")

    def get_formatted_report(self):
        if not self.last_result:
            return "VALIDATION REPORT\n\nNo validation has been run yet."

        lines = []
        lines.append("VALIDATION REPORT")
        lines.append("=" * 50)
        lines.append(f"Status: {'PASS' if self.last_result.get('success') else 'FAIL'}")
        lines.append(f"Message: {self.get_message()}")

        lines.append("\nERRORS:")
        if self.get_errors():
            for item in self.get_errors():
                lines.append(f"- {item}")
        else:
            lines.append("- None")

        lines.append("\nWARNINGS:")
        if self.get_warnings():
            for item in self.get_warnings():
                lines.append(f"- {item}")
        else:
            lines.append("- None")

        lines.append("\nINFO:")
        if self.get_info():
            for item in self.get_info():
                lines.append(f"- {item}")
        else:
            lines.append("- None")

        return "\n".join(lines)

    # ==========================================================
    # DEBUG
    # ==========================================================
    def get_debug_summary(self):
        return {
            "has_result": self.has_result(),
            "last_success": self.last_result.get("success", False) if self.last_result else False,
            "errors_count": len(self.get_errors()),
            "warnings_count": len(self.get_warnings()),
            "info_count": len(self.get_info()),
            "last_error": self.last_error,
        }

    def print_debug_summary(self):
        info = self.get_debug_summary()
        print("============= VALIDATOR DEBUG =============")
        print(f"Has Result       : {info['has_result']}")
        print(f"Last Success     : {info['last_success']}")
        print(f"Errors Count     : {info['errors_count']}")
        print(f"Warnings Count   : {info['warnings_count']}")
        print(f"Info Count       : {info['info_count']}")
        print(f"Last Error       : {info['last_error']}")
        print("===========================================")

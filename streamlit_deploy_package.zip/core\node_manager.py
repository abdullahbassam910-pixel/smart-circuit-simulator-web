﻿class NodeManager:
    """
    Node / connectivity manager for circuit analysis.

    Responsibilities
    ----------------
    - Register component pins as raw nodes
    - Merge connected pins through a union-find structure
    - Track a ground reference node
    - Build stable solver indexes for super-nodes
    - Expose debug-friendly grouped node views
    """

    GROUND_TYPES = ("ground", "gnd")

    def __init__(self):
        self.reset()

    # ==========================================================
    # INTERNAL HELPERS
    # ==========================================================
    def _normalize_node_name(self, node_name):
        """
        Convert a raw node identifier into a safe string key.
        """
        if node_name is None:
            return None

        normalized = str(node_name).strip()
        return normalized or None

    def _invalidate_cache(self):
        """
        Connectivity changes invalidate cached groups and solver indexes.
        """
        self.node_to_index = {}
        self.index_to_node = {}
        self.root_groups = {}

    def _clear_last_error(self):
        self.last_error = ""

    def _set_last_error(self, message):
        self.last_error = str(message)
        return False

    def _get_component_type(self, comp):
        raw = getattr(comp, "comp_type", getattr(comp, "type", "Component"))
        return str(raw).strip()

    def _get_component_type_lower(self, comp):
        return self._get_component_type(comp).lower()

    def _ensure_node_exists(self, node_name):
        """
        Internal safe node creation.
        """
        return self.create_node(node_name)

    def _make_pin_name(self, component_id, pin_number):
        """
        Create a standard pin node name such as comp001_p1.
        """
        component_key = self._normalize_node_name(component_id)
        pin_key = self._normalize_node_name(pin_number)

        if component_key is None or pin_key is None:
            return None

        return f"{component_key}_p{pin_key}"

    def _get_pin_count(self, comp):
        try:
            count = int(getattr(comp, "PIN_COUNT", getattr(comp, "pin_count", 2)))
        except Exception:
            count = 2
        return max(1, count)

    # ==========================================================
    # BASIC NODE OPERATIONS
    # ==========================================================
    def create_node(self, node_name, label=None, metadata=None):
        """
        Create a node if it does not already exist.
        """
        node_key = self._normalize_node_name(node_name)
        if node_key is None:
            return None

        if node_key not in self.parent:
            self.parent[node_key] = node_key
            self.rank[node_key] = 0
            self._invalidate_cache()

        if label is not None:
            self.node_labels[node_key] = label

        if metadata is not None:
            self.node_metadata[node_key] = dict(metadata)

        return node_key

    def has_node(self, node_name):
        """
        Check whether a node exists.
        """
        node_key = self._normalize_node_name(node_name)
        if node_key is None:
            return False
        return node_key in self.parent

    # ==========================================================
    # VALIDATION
    # ==========================================================
    def _is_valid_component(self, comp):
        if comp is None:
            return False
        if getattr(comp, "deleted", False):
            return False
        if self._normalize_node_name(getattr(comp, "id", None)) is None:
            return False
        return True

    def _is_valid_wire(self, wire):
        if wire is None:
            return False
        if getattr(wire, "deleted", False):
            return False
        if not hasattr(wire, "start_comp") or not hasattr(wire, "end_comp"):
            return False
        if not hasattr(wire, "start_pin") or not hasattr(wire, "end_pin"):
            return False
        if wire.start_comp is None or wire.end_comp is None:
            return False
        if not self._is_valid_component(wire.start_comp):
            return False
        if not self._is_valid_component(wire.end_comp):
            return False
        if self._normalize_node_name(wire.start_pin) is None:
            return False
        if self._normalize_node_name(wire.end_pin) is None:
            return False
        return True

    # ==========================================================
    # UNION-FIND
    # ==========================================================
    def find(self, node_name):
        """
        Find the root of a node using path compression.
        """
        node_key = self._normalize_node_name(node_name)
        if node_key is None:
            return None

        self._ensure_node_exists(node_key)

        if self.parent[node_key] != node_key:
            self.parent[node_key] = self.find(self.parent[node_key])

        return self.parent[node_key]

    def find_root(self, node_name):
        return self.find(node_name)

    def union(self, node_a, node_b):
        """
        Merge two nodes by rank.
        Returns True if a merge happened, otherwise False.
        """
        root_a = self.find(node_a)
        root_b = self.find(node_b)

        if root_a is None or root_b is None:
            return self._set_last_error("Cannot merge invalid nodes.")

        if root_a == root_b:
            self._clear_last_error()
            return False

        ground_root = self.get_ground_root()
        if ground_root is not None:
            if root_a == ground_root:
                self.parent[root_b] = root_a
                self._invalidate_cache()
                self._clear_last_error()
                return True

            if root_b == ground_root:
                self.parent[root_a] = root_b
                self._invalidate_cache()
                self._clear_last_error()
                return True

        rank_a = self.rank[root_a]
        rank_b = self.rank[root_b]

        if rank_a < rank_b:
            self.parent[root_a] = root_b
        elif rank_a > rank_b:
            self.parent[root_b] = root_a
        else:
            self.parent[root_b] = root_a
            self.rank[root_a] += 1

        self._invalidate_cache()
        self._clear_last_error()
        return True

    def merge_nodes(self, node_a, node_b):
        return self.union(node_a, node_b)

    def merge_pin_to_pin(self, comp1_id, pin1, comp2_id, pin2):
        node1 = self._make_pin_name(comp1_id, pin1)
        node2 = self._make_pin_name(comp2_id, pin2)
        return self.union(node1, node2)

    # ==========================================================
    # REGISTRATION
    # ==========================================================
    def register_component_pins(self, comp):
        """
        Register a standard two-pin component.
        """
        if not self._is_valid_component(comp):
            return False

        comp_type = self._get_component_type(comp)
        comp_type_lower = comp_type.lower()
        pin_count = self._get_pin_count(comp)

        for pin_number in range(1, pin_count + 1):
            pin = self._make_pin_name(comp.id, pin_number)
            self.create_node(
                pin,
                label=f"{comp_type}:{comp.id}:pin{pin_number}",
                metadata={"component_id": comp.id, "pin": pin_number, "type": comp_type},
            )

        if comp_type_lower in self.GROUND_TYPES:
            pin1 = self._make_pin_name(comp.id, 1)
            pin2 = self._make_pin_name(comp.id, 2)
            self.merge_nodes(pin1, pin2)

        return True

    def register_all_component_pins(self, components):
        if components is None:
            return 0

        count = 0
        for comp in components:
            if self.register_component_pins(comp):
                count += 1

        return count

    def register_custom_node(self, node_name, label=None, metadata=None):
        return self.create_node(node_name, label=label, metadata=metadata)

    # ==========================================================
    # GROUND HANDLING
    # ==========================================================
    def set_as_ground(self, component_id, pin_number):
        node_name = self._make_pin_name(component_id, pin_number)
        return self.set_node_as_ground(node_name)

    def set_node_as_ground(self, node_name):
        root = self.find(node_name)
        if root is None:
            return None

        self.ground_node = root
        self.build_node_map()
        self._clear_last_error()
        return self.ground_node

    def clear_ground(self):
        self.ground_node = None
        self.build_node_map()
        self._clear_last_error()

    def get_ground_root(self):
        if self.ground_node is None:
            return None
        return self.find(self.ground_node)

    def has_ground(self):
        return self.get_ground_root() is not None

    def _auto_detect_ground(self, components):
        if components is None:
            return False

        first_ground = None
        for comp in components:
            if not self._is_valid_component(comp):
                continue

            if self._get_component_type_lower(comp) in self.GROUND_TYPES:
                ground_pin = self._make_pin_name(comp.id, 1)
                if first_ground is None:
                    first_ground = ground_pin
                    self.set_node_as_ground(first_ground)
                else:
                    self.merge_nodes(first_ground, ground_pin)

        if first_ground is not None:
            self.set_node_as_ground(first_ground)
            return True

        return False

    # ==========================================================
    # CIRCUIT SYNC
    # ==========================================================
    def sync_circuit(self, components, wires):
        """
        Rebuild connectivity from the current component and wire lists.
        """
        self.reset()

        components = components or []
        wires = wires or []

        self.last_components_count = len(components)
        self.last_wires_count = len(wires)
        self.last_sync_ok = False
        self._clear_last_error()

        self.register_all_component_pins(components)

        wire_merge_errors = []
        for wire in wires:
            if not self._is_valid_wire(wire):
                continue

            pin_a = self._make_pin_name(wire.start_comp.id, wire.start_pin)
            pin_b = self._make_pin_name(wire.end_comp.id, wire.end_pin)

            if not self.merge_nodes(pin_a, pin_b):
                if self.last_error:
                    wire_merge_errors.append(self.last_error)

        self._auto_detect_ground(components)
        self.build_node_map()
        self.rebuild_root_groups()

        if wire_merge_errors:
            self.last_error = wire_merge_errors[-1]

        self.last_sync_ok = True
        return True

    # ==========================================================
    # GROUPING / MAPPING
    # ==========================================================
    def rebuild_root_groups(self):
        grouped = {}

        for node_name in sorted(self.parent):
            root = self.find(node_name)
            grouped.setdefault(root, []).append(node_name)

        self.root_groups = grouped
        return dict(grouped)

    def build_node_map(self):
        """
        Build root -> solver index mapping.

        Rules:
        - Ground node gets index 0 if it exists
        - Other nodes follow in sorted root order
        """
        self.node_to_index = {}
        self.index_to_node = {}

        if not self.parent:
            return {}

        unique_roots = {self.find(node_name) for node_name in self.parent}
        unique_roots.discard(None)

        ground_root = self.get_ground_root()
        ordered_roots = []

        if ground_root in unique_roots:
            ordered_roots.append(ground_root)

        for root in sorted(unique_roots):
            if root != ground_root:
                ordered_roots.append(root)

        for index, root in enumerate(ordered_roots):
            self.node_to_index[root] = index
            self.index_to_node[index] = root

        return dict(self.node_to_index)

    def get_root_mapping(self):
        if not self.node_to_index and self.parent:
            self.build_node_map()
        return dict(self.node_to_index)

    def get_index_mapping(self):
        if not self.index_to_node and self.parent:
            self.build_node_map()
        return dict(self.index_to_node)

    # ==========================================================
    # QUERY METHODS
    # ==========================================================
    def get_node_index(self, component_id, pin_number):
        node_name = self._make_pin_name(component_id, pin_number)
        return self.get_node_index_by_name(node_name)

    def get_node_index_by_name(self, node_name):
        root = self.find(node_name)
        if root is None:
            return -1

        if not self.node_to_index:
            self.build_node_map()

        return self.node_to_index.get(root, -1)

    def get_root_name(self, component_id, pin_number):
        node_name = self._make_pin_name(component_id, pin_number)
        return self.find(node_name)

    def get_root_of_node(self, node_name):
        return self.find(node_name)

    def get_total_nodes(self):
        if not self.node_to_index and self.parent:
            self.build_node_map()
        return len(self.node_to_index)

    def get_total_raw_pins(self):
        return len(self.parent)

    def get_all_roots(self):
        roots = {self.find(node_name) for node_name in self.parent}
        roots.discard(None)
        return sorted(roots)

    def is_connected(self, comp1_id, pin1, comp2_id, pin2):
        node1 = self._make_pin_name(comp1_id, pin1)
        node2 = self._make_pin_name(comp2_id, pin2)
        return self.are_nodes_connected(node1, node2)

    def are_nodes_connected(self, node_a, node_b):
        root_a = self.find(node_a)
        root_b = self.find(node_b)
        if root_a is None or root_b is None:
            return False
        return root_a == root_b

    def is_ground_node(self, component_id, pin_number):
        node_name = self._make_pin_name(component_id, pin_number)
        return self.is_node_ground(node_name)

    def is_node_ground(self, node_name):
        ground_root = self.get_ground_root()
        if ground_root is None:
            return False
        return self.find(node_name) == ground_root

    def get_nodes_grouped(self):
        if not self.root_groups and self.parent:
            self.rebuild_root_groups()
        return {root: list(nodes) for root, nodes in self.root_groups.items()}

    def get_nodes_in_root(self, root_name):
        if not self.root_groups and self.parent:
            self.rebuild_root_groups()
        return list(self.root_groups.get(root_name, []))

    def get_label(self, node_name):
        node_key = self._normalize_node_name(node_name)
        if node_key is None:
            return None
        return self.node_labels.get(node_key)

    def get_metadata(self, node_name):
        node_key = self._normalize_node_name(node_name)
        if node_key is None:
            return {}
        return dict(self.node_metadata.get(node_key, {}))

    def get_solver_node_table(self):
        grouped = self.get_nodes_grouped()
        ground_root = self.get_ground_root()
        table = []

        for root, index in self.get_root_mapping().items():
            table.append({
                "index": index,
                "root": root,
                "nodes": grouped.get(root, []),
                "is_ground": ground_root is not None and root == ground_root,
            })

        table.sort(key=lambda item: item["index"])
        return table

    # ==========================================================
    # DEBUG / PRINT
    # ==========================================================
    def get_debug_summary(self):
        return {
            "raw_nodes": self.get_total_raw_pins(),
            "super_nodes": self.get_total_nodes(),
            "ground_root": self.get_ground_root(),
            "components_count": self.last_components_count,
            "wires_count": self.last_wires_count,
            "last_sync_ok": self.last_sync_ok,
            "last_error": self.last_error,
        }

    def print_debug_summary(self):
        summary = self.get_debug_summary()
        print("========== NODE MANAGER DEBUG ==========")
        print(f"Raw Nodes      : {summary['raw_nodes']}")
        print(f"Super Nodes    : {summary['super_nodes']}")
        print(f"Ground Root    : {summary['ground_root']}")
        print(f"Components     : {summary['components_count']}")
        print(f"Wires          : {summary['wires_count']}")
        print(f"Last Sync OK   : {summary['last_sync_ok']}")
        print(f"Last Error     : {summary['last_error']}")
        print("========================================")

    def print_nodes(self):
        grouped = self.get_nodes_grouped()
        print("========== SUPER NODES ==========")

        if not grouped:
            print("No nodes found.")
            print("=================================")
            return

        ground_root = self.get_ground_root()

        for root in sorted(grouped):
            idx = self.node_to_index.get(root, "?")
            label = f"[Index {idx}] {root}"

            if ground_root is not None and root == ground_root:
                label += "   <-- GROUND"

            print(label)

            for node_name in grouped[root]:
                readable = self.get_label(node_name)
                if readable:
                    print(f"   - {node_name}   ({readable})")
                else:
                    print(f"   - {node_name}")

        print("=================================")

    # ==========================================================
    # RESET
    # ==========================================================
    def reset(self):
        self.parent = {}
        self.rank = {}
        self.node_labels = {}
        self.node_metadata = {}
        self.node_to_index = {}
        self.index_to_node = {}
        self.root_groups = {}
        self.ground_node = None

        self.last_components_count = 0
        self.last_wires_count = 0
        self.last_sync_ok = False
        self.last_error = ""

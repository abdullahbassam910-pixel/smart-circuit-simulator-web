import numpy as np


class SimulationAnalyzer:
    """
    Simulation analyzer and result processor.

    Responsibilities
    ----------------
    - Run circuit analysis through solver
    - Store the last analysis result
    - Provide formatted reports
    - Extract voltage/current/power output
    - Generate engineering insights and warnings
    - Prepare clean text for UI panels
    - Support DC and transient result summaries
    """

    def __init__(self, solver=None):
        self.solver = solver
        self.last_results = None

        self.last_run_success = False
        self.last_message = "No analysis run."
        self.last_components_count = 0
        self.last_wires_count = 0
        self.last_analysis_mode = "dc"

    # ==========================================================
    # ATTACHMENTS
    # ==========================================================
    def set_solver(self, solver):
        """
        Attach or replace solver.
        """
        self.solver = solver

    # ==========================================================
    # INTERNAL HELPERS
    # ==========================================================
    def _build_failure_result(self, message):
        result = {
            "success": False,
            "message": str(message),
        }
        self.last_results = result
        self.last_run_success = False
        self.last_message = result["message"]
        return result

    def _safe_float(self, value, default=0.0):
        try:
            return float(value)
        except Exception:
            return float(default)

    def _get_result_list(self, key):
        if not isinstance(self.last_results, dict):
            return []
        data = self.last_results.get(key, [])
        if isinstance(data, list):
            return list(data)
        return []

    def _get_result_dict(self, key):
        if not isinstance(self.last_results, dict):
            return {}
        data = self.last_results.get(key, {})
        if isinstance(data, dict):
            return dict(data)
        return {}

    # ==========================================================
    # EXECUTION ENGINE
    # ==========================================================
    def run_analysis(self, components=None, wires=None, **solve_kwargs):
        """
        Run full simulation analysis using solver.

        Returns
        -------
        dict
            Analysis result.
        """
        if self.solver is None:
            return self._build_failure_result("Solver engine not initialized.")

        components = components or []
        wires = wires or []

        self.last_components_count = len(
            [c for c in components if not getattr(c, "deleted", False)]
        )
        self.last_wires_count = len(
            [w for w in wires if not getattr(w, "deleted", False)]
        )

        try:
            result = self.solver.solve(components, wires, **solve_kwargs)
        except Exception as exc:
            result = {
                "success": False,
                "message": f"Analyzer failed while calling solver: {exc}",
            }

        if not isinstance(result, dict):
            result = {
                "success": False,
                "message": "Solver returned an invalid result format.",
            }

        self.last_results = result
        self.last_run_success = bool(result.get("success", False))
        self.last_message = result.get("message", "Unknown result")
        self.last_analysis_mode = result.get("analysis_mode", self.last_analysis_mode)

        return self.last_results

    # ==========================================================
    # RAW RESULT ACCESS
    # ==========================================================
    def has_results(self):
        """
        Check if analyzer has any stored result.
        """
        return isinstance(self.last_results, dict)

    def is_success(self):
        """
        Check whether last analysis was successful.
        """
        return bool(self.has_results() and self.last_results.get("success", False))

    def get_results(self):
        """
        Return full last result.
        """
        return self.last_results

    def get_message(self):
        """
        Return last solver/analyzer message.
        """
        if not self.has_results():
            return "No analysis run."
        return self.last_results.get("message", "No message available.")

    def get_analysis_mode(self):
        """
        Return last analysis mode.
        """
        if not self.has_results():
            return self.last_analysis_mode
        return self.last_results.get("analysis_mode", self.last_analysis_mode)

    # ==========================================================
    # NODE VOLTAGES
    # ==========================================================
    def get_node_voltages(self):
        """
        Return list of node voltages.
        """
        if not self.is_success():
            return []
        return self._get_result_list("node_voltages")

    def get_node_voltage(self, node_index):
        """
        Return voltage of a specific node index.
        """
        voltages = self.get_node_voltages()

        if not isinstance(node_index, int):
            return None

        if node_index < 0 or node_index >= len(voltages):
            return None

        return voltages[node_index]

    def get_voltage_table(self):
        """
        Return formatted node voltage table data.
        """
        table = []

        for index, voltage in enumerate(self.get_node_voltages()):
            table.append(
                {
                    "node": index,
                    "voltage": self._safe_float(voltage),
                    "is_ground": index == 0,
                }
            )

        return table

    # ==========================================================
    # COMPONENT OUTPUT
    # ==========================================================
    def get_component_results(self):
        """
        Return all component result entries.
        """
        if not self.is_success():
            return []
        return self._get_result_list("component_results")

    def get_component_stats(self, comp_id):
        """
        Return result data for one component by id.
        """
        if not self.has_results():
            return None

        for result in self._get_result_list("component_results"):
            if result.get("id") == comp_id:
                return result

        return None

    def get_component_voltage(self, comp_id):
        """
        Return voltage drop across a component.
        """
        stats = self.get_component_stats(comp_id)
        if stats is None:
            return None
        return stats.get("v_drop")

    def get_component_current(self, comp_id):
        """
        Return current through a component.
        """
        stats = self.get_component_stats(comp_id)
        if stats is None:
            return None
        return stats.get("current")

    def get_component_power(self, comp_id):
        """
        Return power of a component.
        """
        stats = self.get_component_stats(comp_id)
        if stats is None:
            return None
        return stats.get("power")

    def get_voltage_current_output(self):
        """
        Return clean engineering output for UI/result panel.
        """
        if not self.is_success():
            return []

        output = []

        for component in self.get_component_results():
            output.append(
                {
                    "id": component.get("id"),
                    "type": component.get("type"),
                    "voltage": component.get("v_drop", 0.0),
                    "current": component.get("current", 0.0),
                    "power": component.get("power", 0.0),
                    "mode": component.get("mode"),
                    "model": component.get("model"),
                }
            )

        return output

    # ==========================================================
    # POWER / EFFICIENCY
    # ==========================================================
    def get_power_balance(self):
        """
        Return generated / consumed power data.
        """
        if not self.is_success():
            return {"generated": 0.0, "consumed": 0.0}

        power_balance = self._get_result_dict("power_balance")
        return {
            "generated": self._safe_float(power_balance.get("generated", 0.0)),
            "consumed": self._safe_float(power_balance.get("consumed", 0.0)),
        }

    def get_total_generated_power(self):
        """
        Return total generated power.
        """
        return self._safe_float(self.get_power_balance().get("generated", 0.0))

    def get_total_consumed_power(self):
        """
        Return total consumed power.
        """
        return self._safe_float(self.get_power_balance().get("consumed", 0.0))

    def get_efficiency(self):
        """
        Estimate power efficiency percentage.
        """
        if not self.is_success():
            return 0.0

        generated = self.get_total_generated_power()
        consumed = self.get_total_consumed_power()

        if abs(generated) < 1e-15:
            return 0.0

        return (consumed / generated) * 100.0

    # ==========================================================
    # TRANSIENT ACCESS
    # ==========================================================
    def get_transient_snapshots(self):
        """
        Return transient snapshots if available.
        """
        if not self.is_success():
            return []
        return self._get_result_list("transient_snapshots")

    def has_transient_data(self):
        """
        Check if transient data exists.
        """
        return len(self.get_transient_snapshots()) > 0

    def get_last_transient_snapshot(self):
        """
        Return the last transient snapshot.
        """
        snapshots = self.get_transient_snapshots()
        if not snapshots:
            return None
        return snapshots[-1]

    # ==========================================================
    # ADVANCED ANALYTICS
    # ==========================================================
    def get_peak_voltage_node(self):
        """
        Return node index and voltage of highest-voltage node.
        """
        voltages = self.get_node_voltages()
        if not voltages:
            return None, 0.0

        max_voltage = max(voltages)
        return voltages.index(max_voltage), self._safe_float(max_voltage)

    def get_lowest_voltage_node(self):
        """
        Return node index and voltage of lowest-voltage node.
        """
        voltages = self.get_node_voltages()
        if not voltages:
            return None, 0.0

        min_voltage = min(voltages)
        return voltages.index(min_voltage), self._safe_float(min_voltage)

    def get_average_node_voltage(self):
        """
        Return average node voltage.
        """
        voltages = self.get_node_voltages()
        if not voltages:
            return 0.0
        return self._safe_float(np.mean(voltages))

    def get_total_current_magnitude(self):
        """
        Sum of absolute component currents.
        """
        if not self.is_success():
            return 0.0

        total = 0.0
        for component in self.get_component_results():
            total += abs(self._safe_float(component.get("current", 0.0)))

        return total

    def get_most_loaded_component(self):
        """
        Return component with highest absolute power.
        """
        if not self.is_success():
            return None

        components = self.get_component_results()
        if not components:
            return None

        return max(components, key=lambda item: abs(self._safe_float(item.get("power", 0.0))))

    def get_highest_current_component(self):
        """
        Return component with highest absolute current.
        """
        if not self.is_success():
            return None

        components = self.get_component_results()
        if not components:
            return None

        return max(components, key=lambda item: abs(self._safe_float(item.get("current", 0.0))))

    def get_warning_messages(self):
        """
        Generate useful engineering warnings / notes.
        """
        warnings = []

        if not self.has_results():
            return ["No analysis data available."]

        if not self.is_success():
            return [self.get_message()]

        peak_idx, peak_voltage = self.get_peak_voltage_node()
        low_idx, low_voltage = self.get_lowest_voltage_node()

        if peak_idx is not None and peak_voltage > 12.0:
            warnings.append(f"High voltage alert: Node {peak_idx} = {peak_voltage:.3f} V")

        if low_idx is not None and low_voltage < -12.0:
            warnings.append(f"Negative voltage alert: Node {low_idx} = {low_voltage:.3f} V")

        most_loaded = self.get_most_loaded_component()
        if most_loaded is not None:
            power = self._safe_float(most_loaded.get("power", 0.0))
            if abs(power) > 5.0:
                warnings.append(
                    f"High power component: {most_loaded.get('type')} "
                    f"({most_loaded.get('id')}) = {power:.3f} W"
                )

        highest_current = self.get_highest_current_component()
        if highest_current is not None:
            current = self._safe_float(highest_current.get("current", 0.0))
            if abs(current) > 2.0:
                warnings.append(
                    f"High current path: {highest_current.get('type')} "
                    f"({highest_current.get('id')}) = {current:.3f} A"
                )

        if self.get_analysis_mode() == "transient" and self.has_transient_data():
            warnings.append(
                "Transient simulation mode was used. Review time snapshots for capacitor behavior."
            )

        if not warnings:
            warnings.append("No critical warnings detected.")

        return warnings

    def get_insights(self):
        """
        Return compact analysis insights.
        """
        if not self.is_success():
            return []

        insights = []

        peak_idx, peak_voltage = self.get_peak_voltage_node()
        low_idx, low_voltage = self.get_lowest_voltage_node()
        average_voltage = self.get_average_node_voltage()

        if peak_idx is not None:
            insights.append(f"Peak voltage is at Node {peak_idx}: {peak_voltage:.3f} V")

        if low_idx is not None:
            insights.append(f"Lowest voltage is at Node {low_idx}: {low_voltage:.3f} V")

        insights.append(f"Average node voltage: {average_voltage:.3f} V")
        insights.append(f"Estimated efficiency: {self.get_efficiency():.2f}%")

        loaded = self.get_most_loaded_component()
        if loaded is not None:
            insights.append(
                f"Most loaded component: {loaded.get('type')} "
                f"({loaded.get('id')}) with {self._safe_float(loaded.get('power', 0.0)):.3f} W"
            )

        if self.get_analysis_mode() == "transient" and self.has_transient_data():
            snapshot = self.get_last_transient_snapshot()
            if snapshot is not None:
                insights.append(
                    f"Transient finished at t={self._safe_float(snapshot.get('time', 0.0)):.6f} s "
                    f"after {int(snapshot.get('step', 0))} steps"
                )

        return insights

    # ==========================================================
    # FORMATTING
    # ==========================================================
    def format_voltage_output(self):
        """
        Return formatted voltage section.
        """
        if not self.is_success():
            return "No valid voltage data."

        lines = ["NODE VOLTAGES", "-" * 30]

        for row in self.get_voltage_table():
            ground_text = " (GND)" if row["is_ground"] else ""
            lines.append(f"Node {row['node']}: {row['voltage']:>9.4f} V{ground_text}")

        return "\n".join(lines)

    def format_current_output(self):
        """
        Return formatted current section.
        """
        if not self.is_success():
            return "No valid current data."

        lines = ["COMPONENT CURRENTS", "-" * 30]

        for component in self.get_component_results():
            lines.append(
                f"{component.get('type')} ({component.get('id')}): "
                f"{self._safe_float(component.get('current', 0.0)):>9.6f} A"
            )

        return "\n".join(lines)

    def format_component_output(self):
        """
        Return formatted component engineering output.
        """
        if not self.is_success():
            return "No valid component analysis data."

        lines = ["COMPONENT RESULTS", "-" * 30]

        for component in self.get_component_results():
            lines.append(f"{component.get('type')} [{component.get('id')}]")
            lines.append(f"  Voltage Drop : {self._safe_float(component.get('v_drop', 0.0)):>9.6f} V")
            lines.append(f"  Current      : {self._safe_float(component.get('current', 0.0)):>9.6f} A")
            lines.append(f"  Power        : {self._safe_float(component.get('power', 0.0)):>9.6f} W")

            if component.get("mode") is not None:
                lines.append(f"  Mode         : {component.get('mode')}")
            if component.get("model") is not None:
                lines.append(f"  Model        : {component.get('model')}")
            if component.get("time_step") is not None:
                lines.append(f"  Time Step    : {component.get('time_step')}")
            if component.get("previous_voltage") is not None:
                lines.append(f"  Prev Voltage : {component.get('previous_voltage')}")

        return "\n".join(lines)

    def format_power_output(self):
        """
        Return formatted power balance section.
        """
        if not self.is_success():
            return "No valid power data."

        power_balance = self.get_power_balance()

        lines = [
            "POWER BALANCE",
            "-" * 30,
            f"Generated : {self._safe_float(power_balance.get('generated', 0.0)):.6f} W",
            f"Consumed  : {self._safe_float(power_balance.get('consumed', 0.0)):.6f} W",
            f"Efficiency: {self.get_efficiency():.2f}%",
        ]

        return "\n".join(lines)

    def format_warning_output(self):
        """
        Return formatted warnings section.
        """
        lines = ["ANALYSIS WARNINGS", "-" * 30]

        for message in self.get_warning_messages():
            lines.append(f"- {message}")

        return "\n".join(lines)

    def format_transient_output(self):
        """
        Return formatted transient snapshot section.
        """
        if not self.has_transient_data():
            return "No transient snapshot data."

        lines = ["TRANSIENT SNAPSHOTS", "-" * 30]

        for snapshot in self.get_transient_snapshots():
            lines.append(
                f"Step {snapshot.get('step')}: "
                f"t={snapshot.get('time')} s | "
                f"nodes={snapshot.get('node_voltages')}"
            )

        return "\n".join(lines)

    def get_result_formatting(self):
        """
        Main combined formatted result string for UI panel.
        """
        if not self.has_results():
            return "NO DATA: Please run simulation first."

        if not self.is_success():
            return f"ANALYSIS FAILED\nReason: {self.get_message()}"

        sections = [
            "==================================",
            "      SMART CIRCUIT ANALYZER",
            "==================================",
            "",
            self.format_voltage_output(),
            "",
            self.format_current_output(),
            "",
            self.format_component_output(),
            "",
            self.format_power_output(),
        ]

        if self.has_transient_data():
            sections.extend(["", self.format_transient_output()])

        sections.extend(["", self.format_warning_output()])

        return "\n".join(sections)

    def get_pro_report(self):
        """
        Return a short, clear report for the modern overlay.
        """
        if not self.has_results():
            return "No result yet\nRun the simulation to see a short explanation."

        if not self.is_success():
            return (
                "Circuit needs a fix\n\n"
                f"{self.get_message()}\n\n"
                "Try this:\n"
                "- Add one Ground\n"
                "- Connect every part with wire\n"
                "- Press CHECK, then RUN"
            )

        result = self.last_results
        solver_info = result.get("solver_info", {})
        power_balance = self.get_power_balance()
        mode = solver_info.get("analysis_mode", self.get_analysis_mode())
        node_count = len(self.get_node_voltages())
        component_count = len(self.get_component_results())
        generated = self._safe_float(power_balance.get("generated", 0.0))
        consumed = self._safe_float(power_balance.get("consumed", 0.0))
        peak_idx, peak_voltage = self.get_peak_voltage_node()
        low_idx, low_voltage = self.get_lowest_voltage_node()
        total_current = self.get_total_current_magnitude()
        main_message = self._get_plain_result_message(total_current, generated, consumed)

        lines = [
            "Circuit solved",
            f"{main_message}",
            "",
            "At a glance",
            f"Mode: {mode}   Nodes: {node_count}   Parts: {component_count}",
            f"Voltage range: {low_voltage:.2f} V to {peak_voltage:.2f} V",
            f"Current level: {total_current:.6f} A",
            f"Power: made {generated:.6f} W / used {consumed:.6f} W",
            "",
            "Important points",
            f"Highest: Node {peak_idx} = {peak_voltage:.2f} V",
            f"Lowest : Node {low_idx} = {low_voltage:.2f} V",
        ]

        simple_parts = self._get_simple_component_lines(limit=4)
        if simple_parts:
            lines.extend(["", "Parts"])
            lines.extend(simple_parts)

        warning_messages = self.get_warning_messages()
        useful_warnings = [msg for msg in warning_messages if "No critical warnings" not in msg]
        if useful_warnings:
            lines.extend(["", "Note"])
            lines.append(useful_warnings[0])

        if self.has_transient_data():
            snapshot = self.get_last_transient_snapshot()
            lines.extend(
                [
                    "",
                    "Time result",
                    f"Last point: {self._safe_float(snapshot.get('time', 0.0)):.6f} s",
                ]
            )

        lines.extend(["", "Next: open Graphs for the visual view."])

        return "\n".join(lines)

    def _get_plain_result_message(self, total_current, generated, consumed):
        if abs(total_current) < 1e-9:
            return "The circuit has voltage, but almost no current is flowing."

        if abs(generated) < 1e-9 and abs(consumed) < 1e-9:
            return "The circuit is connected, but power is almost zero."

        return "Current is flowing and the circuit has usable results."

    def _get_simple_component_lines(self, limit=4):
        lines = []
        components = self.get_component_results()

        for component in components[:limit]:
            comp_type = component.get("type", "Component")
            voltage = self._safe_float(component.get("v_drop", 0.0))
            current = self._safe_float(component.get("current", 0.0))
            status = self._describe_component_status(
                comp_type,
                voltage,
                current,
                self._safe_float(component.get("power", 0.0)),
                component,
            )
            lines.append(f"- {comp_type}: {voltage:.2f} V, {current:.6f} A")
            lines.append(f"  {status}")

        remaining = len(components) - limit
        if remaining > 0:
            lines.append(f"- {remaining} more part(s) hidden to keep this short.")

        return lines

    def _describe_component_status(self, comp_type, voltage, current, power, component):
        comp_type = str(comp_type).strip().lower()

        if comp_type == "ground":
            return "This is the 0V reference point."

        if comp_type == "battery":
            if abs(current) < 1e-9:
                return "The source is connected, but almost no current is flowing."
            return "This source is pushing energy into the circuit."

        if comp_type in ("current", "currentsource", "current source"):
            if abs(current) < 1e-9:
                return "The current source is set near zero."
            return "This source is forcing current through its branch."

        if comp_type == "resistor":
            if abs(current) < 1e-9:
                return "Almost no current is passing through this resistor."
            return "This resistor is using power and limiting current."

        if comp_type == "diode":
            mode = str(component.get("mode", "")).upper()
            if "OFF" in mode or abs(current) < 1e-9:
                return "The diode is blocking current."
            return "The diode is allowing current in one direction."

        if comp_type == "led":
            mode = str(component.get("mode", "")).upper()
            if "ON" in mode and abs(current) > 1e-9:
                return "The LED is forward biased and emitting."
            return "The LED is off or reverse biased."

        if comp_type == "switch":
            mode = str(component.get("mode", "")).upper()
            if "CLOSED" in mode:
                return "The switch is closed and conducting."
            return "The switch is open and blocking current."

        if comp_type == "transistor":
            mode = str(component.get("mode", "")).upper()
            if "ON" in mode:
                return "The transistor channel is active in the simplified NPN model."
            return "The transistor is off because base-emitter bias is low."

        if comp_type in ("acsource", "ac source"):
            return "This AC source is represented by its instantaneous voltage in transient mode."

        if comp_type == "capacitor":
            mode = str(component.get("mode", "")).upper()
            if "TRANSIENT" in mode:
                return "The capacitor is changing over time."
            return "The capacitor is acting like an open circuit in DC."

        if abs(power) < 1e-9 and abs(current) < 1e-9:
            return "No meaningful current or power was detected here."

        return "This part is active in the solved circuit."

    # ==========================================================
    # UI-FRIENDLY SHORT OUTPUT
    # ==========================================================
    def get_short_summary(self):
        """
        Return short result text for small output panel.
        """
        if not self.has_results():
            return "No simulation data."

        if not self.is_success():
            return f"Error: {self.get_message()}"

        peak_idx, peak_voltage = self.get_peak_voltage_node()
        power_balance = self.get_power_balance()
        mode = self.get_analysis_mode()

        return (
            f"Analysis OK | "
            f"Mode: {mode} | "
            f"Nodes: {len(self.get_node_voltages())} | "
            f"Peak: Node {peak_idx} = {peak_voltage:.3f} V | "
            f"Power Gen: {self._safe_float(power_balance.get('generated', 0.0)):.3f} W | "
            f"Power Use: {self._safe_float(power_balance.get('consumed', 0.0)):.3f} W"
        )

    # ==========================================================
    # DEBUG
    # ==========================================================
    def get_debug_summary(self):
        """
        Return compact analyzer debug info.
        """
        return {
            "has_solver": self.solver is not None,
            "has_results": self.has_results(),
            "last_run_success": self.last_run_success,
            "last_message": self.last_message,
            "last_components_count": self.last_components_count,
            "last_wires_count": self.last_wires_count,
            "last_analysis_mode": self.last_analysis_mode,
            "node_count": len(self.get_node_voltages()) if self.is_success() else 0,
            "component_result_count": len(self.get_component_results()) if self.is_success() else 0,
            "transient_snapshot_count": len(self.get_transient_snapshots()) if self.is_success() else 0,
        }

    def print_debug_summary(self):
        """
        Print analyzer debug info.
        """
        info = self.get_debug_summary()

        print("============ ANALYZER DEBUG ============")
        print(f"Has Solver              : {info['has_solver']}")
        print(f"Has Results             : {info['has_results']}")
        print(f"Last Run Success        : {info['last_run_success']}")
        print(f"Last Message            : {info['last_message']}")
        print(f"Last Components Count   : {info['last_components_count']}")
        print(f"Last Wires Count        : {info['last_wires_count']}")
        print(f"Last Analysis Mode      : {info['last_analysis_mode']}")
        print(f"Node Count              : {info['node_count']}")
        print(f"Component Result Count  : {info['component_result_count']}")
        print(f"Transient Snapshots     : {info['transient_snapshot_count']}")
        print("========================================")

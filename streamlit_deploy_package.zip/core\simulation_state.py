﻿from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class SolverOptions:
    """
    Main solver configuration for Phase 3 simulation.
    """

    analysis_mode: str = "dc"
    time_step: float = 1e-3
    transient_steps: int = 12
    diode_max_iterations: int = 12
    diode_threshold: float = 1e-9
    regularization: float = 1e-12
    auto_use_transient_for_capacitors: bool = True
    require_ground: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "analysis_mode": self.analysis_mode,
            "time_step": self.time_step,
            "transient_steps": self.transient_steps,
            "diode_max_iterations": self.diode_max_iterations,
            "diode_threshold": self.diode_threshold,
            "regularization": self.regularization,
            "auto_use_transient_for_capacitors": self.auto_use_transient_for_capacitors,
            "require_ground": self.require_ground,
        }

    def copy(self) -> "SolverOptions":
        return SolverOptions(
            analysis_mode=self.analysis_mode,
            time_step=self.time_step,
            transient_steps=self.transient_steps,
            diode_max_iterations=self.diode_max_iterations,
            diode_threshold=self.diode_threshold,
            regularization=self.regularization,
            auto_use_transient_for_capacitors=self.auto_use_transient_for_capacitors,
            require_ground=self.require_ground,
        )

    def update(self, **kwargs) -> "SolverOptions":
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        return self


@dataclass
class CapacitorState:
    """
    Stores historical capacitor values for transient simulation.
    """

    voltage: float = 0.0
    current: float = 0.0
    charge: float = 0.0
    energy: float = 0.0
    last_time: float = 0.0

    def reset(self):
        self.voltage = 0.0
        self.current = 0.0
        self.charge = 0.0
        self.energy = 0.0
        self.last_time = 0.0

    def update_from_solution(self, capacitance_farads: float, voltage: float, current: float, time_value: float):
        self.voltage = float(voltage)
        self.current = float(current)
        self.charge = float(capacitance_farads) * float(voltage)
        self.energy = 0.5 * float(capacitance_farads) * (float(voltage) ** 2)
        self.last_time = float(time_value)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "voltage": self.voltage,
            "current": self.current,
            "charge": self.charge,
            "energy": self.energy,
            "last_time": self.last_time,
        }


@dataclass
class TransientSnapshot:
    """
    One transient simulation sample.
    """

    step: int = 0
    time: float = 0.0
    node_voltages: List[float] = field(default_factory=list)
    component_results: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "time": self.time,
            "node_voltages": list(self.node_voltages),
            "component_results": list(self.component_results),
        }


@dataclass
class AnalysisSummary:
    """
    Lightweight summary object for debug or reporting use.
    """

    success: bool = False
    message: str = "No analysis run."
    analysis_mode: str = "dc"
    num_nodes: int = 0
    num_voltage_sources: int = 0
    matrix_size: int = 0
    time_step: Optional[float] = None
    transient_steps: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "message": self.message,
            "analysis_mode": self.analysis_mode,
            "num_nodes": self.num_nodes,
            "num_voltage_sources": self.num_voltage_sources,
            "matrix_size": self.matrix_size,
            "time_step": self.time_step,
            "transient_steps": self.transient_steps,
        }
